import icon1 from '../../icons/Porcelain-Crowns.png'
import icon2 from '../../icons/2441082.png'
import icon3 from '../../icons/3209072.png'
import icon4 from '../../icons/white-filling.png'
import icon5 from '../../icons/2866146.png'
import icon6 from '../../icons/993248.png'

function Cometics(){
return (
    < div className=' text-center ' >
    <div style={{padding:"40px 0px"}}>
    <h1 className="text-center">We offer a compelte array of general and </h1>
     <h1 className='text-center'> cosmetic services for your oral care </h1>
     </div>
     <div className='Cometics' style={{padding:"30px 0px"}}>
     <div className='iconns1-come row  text-center ' >
     <div className="Icon2-come  col-lg-3 col-sm-12  text-center">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon1} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>Cera Crown</h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div>
    
   
  </div>
</div>
<div className="Icon2-come col-lg-3 col-sm-12 text-center ">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon2} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>Root Canals</h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div>
    
   
  </div>
</div>
<div className="Icon3-come  col-sm-12 col-lg-3 text-center ">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon3} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>Regular Exam </h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div>
    
   
  </div>
</div>


    </div>
    <div className='iconns2-come row  text-center '>
    <div className="Icon1-come col-sm-12  col-lg-3">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon4} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>White Fillings</h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div> 
  </div>
</div>
<div className="Icon2-come col-sm-12  col-lg-3">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon5} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>Dental Care</h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div>
    
   
  </div>
</div>
<div className="Icon2-come col-sm-12  col-lg-3">
    <div className="card text-center" style={{width:"18rem"}}>
  <div className="card-body">
    <img src={icon6} alt="" style={{width:'100px', height:'100px'}}/>
    <h1>Den Implants</h1>
    <p>Important replace missing teeth and act just like your natural teeth</p>
    </div>
    
   
  </div>
</div>


    </div>
    </div>
    </ div>
)
}
export default Cometics;
